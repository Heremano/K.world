create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text unique not null,
 display_name text not null default '',
 bio text not null default '',
 avatar_url text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.posts (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 content text not null default '',
 media_url text,
 media_type text check (media_type in ('image','video') or media_type is null),
 visibility text not null default 'public' check (visibility in ('public','followers','private')),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.comments (
 id uuid primary key default gen_random_uuid(),
 post_id uuid not null references public.posts(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 content text not null,
 created_at timestamptz not null default now()
);

create table if not exists public.likes (
 post_id uuid not null references public.posts(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 created_at timestamptz not null default now(),
 primary key (post_id,user_id)
);

create table if not exists public.follows (
 follower_id uuid not null references public.profiles(id) on delete cascade,
 following_id uuid not null references public.profiles(id) on delete cascade,
 created_at timestamptz not null default now(),
 primary key (follower_id,following_id),
 check (follower_id <> following_id)
);

create table if not exists public.conversations (
 id uuid primary key default gen_random_uuid(),
 created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
 conversation_id uuid not null references public.conversations(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 joined_at timestamptz not null default now(),
 primary key (conversation_id,user_id)
);

create table if not exists public.messages (
 id uuid primary key default gen_random_uuid(),
 conversation_id uuid not null references public.conversations(id) on delete cascade,
 sender_id uuid not null references public.profiles(id) on delete cascade,
 content text not null default '',
 media_url text,
 media_type text check (media_type in ('image','video','file') or media_type is null),
 created_at timestamptz not null default now(),
 read_at timestamptz
);

create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 actor_id uuid references public.profiles(id) on delete set null,
 type text not null check (type in ('like','comment','follow','message','system')),
 post_id uuid references public.posts(id) on delete cascade,
 message text not null default '',
 is_read boolean not null default false,
 created_at timestamptz not null default now()
);

create table if not exists public.reports (
 id uuid primary key default gen_random_uuid(),
 reporter_id uuid not null references public.profiles(id) on delete cascade,
 post_id uuid references public.posts(id) on delete cascade,
 reported_user_id uuid references public.profiles(id) on delete cascade,
 reason text not null,
 status text not null default 'pending' check (status in ('pending','reviewed','resolved','dismissed')),
 created_at timestamptz not null default now()
);

create index if not exists posts_user_created_idx on public.posts(user_id,created_at desc);
create index if not exists comments_post_created_idx on public.comments(post_id,created_at desc);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id,created_at);
create index if not exists notifications_user_created_idx on public.notifications(user_id,created_at desc);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
declare base_username text;
begin
 base_username := lower(regexp_replace(coalesce(new.raw_user_meta_data->>'username',split_part(coalesce(new.email,''),'@',1),'user'),'[^a-zA-Z0-9_]','','g'));
 if base_username='' then base_username:='user'; end if;
 insert into public.profiles(id,username,display_name)
 values(new.id,base_username||'_'||substr(replace(new.id::text,'-',''),1,6),coalesce(new.raw_user_meta_data->>'display_name',''))
 on conflict(id) do nothing;
 return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.likes enable row level security;
alter table public.follows enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;
alter table public.reports enable row level security;

drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select using (true);
drop policy if exists profiles_insert on public.profiles;
create policy profiles_insert on public.profiles for insert with check (auth.uid()=id);
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update using (auth.uid()=id) with check (auth.uid()=id);

drop policy if exists posts_select on public.posts;
create policy posts_select on public.posts for select using (
 visibility='public' or user_id=auth.uid() or
 (visibility='followers' and exists(select 1 from public.follows f where f.follower_id=auth.uid() and f.following_id=posts.user_id))
);
drop policy if exists posts_insert on public.posts;
create policy posts_insert on public.posts for insert with check (auth.uid()=user_id);
drop policy if exists posts_update on public.posts;
create policy posts_update on public.posts for update using (auth.uid()=user_id);
drop policy if exists posts_delete on public.posts;
create policy posts_delete on public.posts for delete using (auth.uid()=user_id);

drop policy if exists comments_select on public.comments;
create policy comments_select on public.comments for select using (true);
drop policy if exists comments_insert on public.comments;
create policy comments_insert on public.comments for insert with check (auth.uid()=user_id);
drop policy if exists comments_update on public.comments;
create policy comments_update on public.comments for update using (auth.uid()=user_id);
drop policy if exists comments_delete on public.comments;
create policy comments_delete on public.comments for delete using (auth.uid()=user_id);

drop policy if exists likes_select on public.likes;
create policy likes_select on public.likes for select using (true);
drop policy if exists likes_insert on public.likes;
create policy likes_insert on public.likes for insert with check (auth.uid()=user_id);
drop policy if exists likes_delete on public.likes;
create policy likes_delete on public.likes for delete using (auth.uid()=user_id);

drop policy if exists follows_select on public.follows;
create policy follows_select on public.follows for select using (true);
drop policy if exists follows_insert on public.follows;
create policy follows_insert on public.follows for insert with check (auth.uid()=follower_id);
drop policy if exists follows_delete on public.follows;
create policy follows_delete on public.follows for delete using (auth.uid()=follower_id);

drop policy if exists members_select on public.conversation_members;
create policy members_select on public.conversation_members for select using (auth.uid()=user_id);
drop policy if exists members_insert on public.conversation_members;
create policy members_insert on public.conversation_members for insert with check (auth.uid()=user_id);
drop policy if exists conversations_select on public.conversations;
create policy conversations_select on public.conversations for select using (exists(select 1 from public.conversation_members m where m.conversation_id=conversations.id and m.user_id=auth.uid()));
drop policy if exists conversations_insert on public.conversations;
create policy conversations_insert on public.conversations for insert with check (auth.uid() is not null);

drop policy if exists messages_select on public.messages;
create policy messages_select on public.messages for select using (exists(select 1 from public.conversation_members m where m.conversation_id=messages.conversation_id and m.user_id=auth.uid()));
drop policy if exists messages_insert on public.messages;
create policy messages_insert on public.messages for insert with check (auth.uid()=sender_id and exists(select 1 from public.conversation_members m where m.conversation_id=messages.conversation_id and m.user_id=auth.uid()));

drop policy if exists notifications_select on public.notifications;
create policy notifications_select on public.notifications for select using (auth.uid()=user_id);
drop policy if exists notifications_update on public.notifications;
create policy notifications_update on public.notifications for update using (auth.uid()=user_id);

drop policy if exists reports_insert on public.reports;
create policy reports_insert on public.reports for insert with check (auth.uid()=reporter_id);
drop policy if exists reports_select on public.reports;
create policy reports_select on public.reports for select using (auth.uid()=reporter_id);


-- Enable realtime safely (running this section more than once will not stop deployment).
do $$ begin
  begin alter publication supabase_realtime add table public.messages; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.notifications; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.posts; exception when duplicate_object then null; end;
end $$;
