"use client"
import { useEffect, useMemo, useState } from "react"
import { Bell, Home as HomeIcon, MessageCircle, Plus, Search, User, PlaySquare, Users, Heart, MessageSquare, Share2, Image, Video, LogIn, LogOut, Send, X } from "lucide-react"
import { hasSupabase, supabase } from "../lib/supabase"

type Profile={id:string;username:string;display_name:string;avatar_url?:string|null}
type Post={id:string;user_id:string;content:string;media_url?:string|null;media_type?:string|null;visibility:string;created_at:string;author?:Profile;likes?:number;comments?:number;liked?:boolean}

export default function Home(){
 const [page,setPage]=useState("Home"),[tab,setTab]=useState("For You"),[posts,setPosts]=useState<Post[]>([]),[session,setSession]=useState<any>(null),[showCreate,setShowCreate]=useState(false),[text,setText]=useState(""),[loading,setLoading]=useState(true),[notice,setNotice]=useState(""),[search,setSearch]=useState("")
 useEffect(()=>{ if(!supabase){setLoading(false);return}; supabase.auth.getSession().then(({data})=>setSession(data.session)); const {data}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s)); return ()=>data.subscription.unsubscribe() },[])
 useEffect(()=>{ if(supabase) loadPosts() },[tab,session])
 async function loadPosts(){
   if(!supabase)return; setLoading(true)
   let q=supabase.from("posts").select("id,user_id,content,media_url,media_type,visibility,created_at,profiles(id,username,display_name,avatar_url),likes(user_id),comments(id)").order("created_at",{ascending:false}).limit(50)
   if(tab==="Shorts") q=q.eq("media_type","video")
   if(tab==="Videos") q=q.eq("media_type","video")
   const {data,error}=await q
   if(error){setNotice(error.message);setPosts([])} else if(data){
     let rows:any[]=data
     if(tab==="Following"&&session){ const {data:f}=await supabase.from("follows").select("following_id").eq("follower_id",session.user.id); const ids=(f||[]).map((x:any)=>x.following_id); rows=ids.length?rows.filter(p=>ids.includes(p.user_id)):[] }
     setPosts(rows.map(p=>({...p,author:p.profiles,likes:p.likes?.length||0,comments:p.comments?.length||0,liked:!!p.likes?.some((l:any)=>l.user_id===session?.user?.id)})))
   }
   setLoading(false)
 }
 async function publish(){
   if(!text.trim())return
   if(!supabase||!session){setNotice("Sign in first to publish a real post.");return}
   const {error}=await supabase.from("posts").insert({user_id:session.user.id,content:text.trim(),visibility:"public"})
   if(error)setNotice(error.message); else {setText("");setShowCreate(false);await loadPosts()}
 }
 async function signOut(){if(supabase)await supabase.auth.signOut();setPage("Home")}
 const filtered=useMemo(()=>posts.filter(p=>!search.trim()||p.content.toLowerCase().includes(search.toLowerCase())||p.author?.username.toLowerCase().includes(search.toLowerCase())||p.author?.display_name.toLowerCase().includes(search.toLowerCase())),[posts,search])
 if(!hasSupabase) return <div className="app"><header className="topbar"><div className="brand">K<span>.</span>World</div></header><main className="center card setup"><h1>K.World is ready to connect</h1><p>Backend connection is not configured. Add your Supabase URL and anon key in Vercel Environment Variables, then redeploy.</p><a href="/auth" className="publish">Open sign in</a></main></div>
 return <div className="app">
  <header className="topbar"><div className="brand">K<span>.</span>World</div><div className="searchWrap"><Search size={18}/><input className="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search K.World"/></div><div className="topActions"><button className="iconBtn" onClick={()=>setPage("Notifications")}><Bell size={20}/></button>{session?<button className="avatar small" onClick={()=>setPage("Profile")}>{(session.user.email?.[0]||"K").toUpperCase()}</button>:<button className="loginBtn" onClick={()=>location.href="/auth"}><LogIn size={17}/> Sign in</button>}</div></header>
  <div className="layout">
   <aside className="side card"><button className="create" onClick={()=>setShowCreate(true)}><Plus size={18}/> Create</button>{[[HomeIcon,"Home"],[PlaySquare,"Shorts"],[Video,"Videos"],[MessageCircle,"Messages"],[Bell,"Notifications"],[Users,"Following"],[User,"Profile"]].map(([I,n]:any)=><button key={n} className={`navbtn ${page===n?"active":""}`} onClick={()=>setPage(n)}><I size={20}/><span>{n}</span></button>)}{session&&<button className="navbtn" onClick={signOut}><LogOut size={20}/><span>Sign out</span></button>}</aside>
   <main className="feed"><div className="pageHead"><div><h1>{page}</h1><p>Connect. Share. Discover. 🌍</p></div><button className="create mobileCreate" onClick={()=>setShowCreate(true)}><Plus size={18}/> Create</button></div>
    {page==="Home"&&<><div className="tabs">{["For You","Following","Shorts","Videos"].map(t=><button className={`tab ${tab===t?"active":""}`} onClick={()=>setTab(t)} key={t}>{t}</button>)}</div><div className="card composer"><div className="avatar">{(session?.user.email?.[0]||"K").toUpperCase()}</div><button className="composerbox" onClick={()=>setShowCreate(true)}>What do you want to share?</button></div>{loading?<div className="card muted">Loading…</div>:filtered.length?filtered.map(p=><PostCard key={p.id} post={p} session={session} onRefresh={loadPosts} onNotice={setNotice}/>):<div className="card empty"><h2>No posts yet</h2><p>Be the first person to share something on K.World.</p></div>}</>}
    {page!=="Home"&&<Section page={page} session={session} onNotice={setNotice}/>} 
   </main>
   <aside className="right"><div className="card"><h3>About K.World</h3><p className="muted">A real social platform for profiles, posts, follows, likes, comments, private conversations and notifications.</p><a href="/kezamutima-samuel" className="profileLink">Kezamutima Samuel →</a></div></aside>
  </div>
  <nav className="mobileNav">{[[HomeIcon,"Home"],[PlaySquare,"Shorts"],[Plus,"Create"],[MessageCircle,"Messages"],[User,"Profile"]].map(([I,n]:any)=><button className={page===n?"active":""} key={n} onClick={()=>n==="Create"?setShowCreate(true):setPage(n)}><I size={22}/><small>{n}</small></button>)}</nav>
  {notice&&<div className="toast">{notice}<button onClick={()=>setNotice("")}><X size={16}/></button></div>}
  {showCreate&&<div className="modalBack"><div className="modal card"><div className="modalHead"><h2>Create post</h2><button className="iconBtn" onClick={()=>setShowCreate(false)}><X/></button></div><textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Share something with K.World…"/><div className="createTools"><button><Image size={18}/> Photo</button><button><Video size={18}/> Video</button><button><PlaySquare size={18}/> Short</button></div><button className="publish" onClick={publish}>Publish</button></div></div>}
 </div>
}

function Section({page,session,onNotice}:{page:string;session:any;onNotice:(s:string)=>void}){
 if(page==="Profile") return <Profile session={session} onNotice={onNotice}/>
 if(page==="Messages") return <div className="card empty"><MessageCircle size={30}/><h2>Private messages</h2><p>Conversations are stored in the connected Supabase database. Sign in to start messaging.</p></div>
 if(page==="Notifications") return <div className="card empty"><Bell size={30}/><h2>Notifications</h2><p>Your likes, comments, follows and messages will appear here.</p></div>
 if(page==="Following") return <div className="card empty"><Users size={30}/><h2>Following</h2><p>Use the follow button on profiles to build your personal feed.</p></div>
 return <div className="card empty"><PlaySquare size={30}/><h2>{page}</h2><p>Real {page.toLowerCase()} content is connected to the K.World database.</p></div>
}

function Profile({session,onNotice}:{session:any;onNotice:(s:string)=>void}){const [p,setP]=useState<any>(null); const [name,setName]=useState(""); const [bio,setBio]=useState(""); useEffect(()=>{if(!supabase||!session)return;supabase.from("profiles").select("*").eq("id",session.user.id).single().then(({data,error})=>{if(error)onNotice(error.message);else{setP(data);setName(data.display_name);setBio(data.bio||"")}})},[session]); async function save(){if(!supabase||!session)return;const {error}=await supabase.from("profiles").update({display_name:name,bio}).eq("id",session.user.id);if(error)onNotice(error.message);else onNotice("Profile updated")}; if(!session)return <div className="card empty"><h2>Your profile</h2><p>Sign in to manage your real K.World profile.</p></div>; return <div className="card profile"><div className="avatar big">{(name?.[0]||"K").toUpperCase()}</div><h2>{name||p?.username||"K.World user"}</h2><p className="muted">@{p?.username||"user"}</p><input value={name} onChange={e=>setName(e.target.value)} placeholder="Display name"/><textarea value={bio} onChange={e=>setBio(e.target.value)} placeholder="Bio"/><button className="publish" onClick={save}>Save profile</button></div>}

function PostCard({post,session,onRefresh,onNotice}:{post:Post;session:any;onRefresh:()=>void;onNotice:(s:string)=>void}){
 const [liked,setLiked]=useState(!!post.liked); const [likes,setLikes]=useState(post.likes||0); const [comment,setComment]=useState("")
 async function like(){if(!supabase||!session){onNotice("Sign in to like posts.");return} if(liked){const {error}=await supabase.from("likes").delete().eq("post_id",post.id).eq("user_id",session.user.id);if(!error){setLiked(false);setLikes(x=>Math.max(0,x-1))}}else{const {error}=await supabase.from("likes").insert({user_id:session.user.id,post_id:post.id});if(!error){setLiked(true);setLikes(x=>x+1)}else onNotice(error.message)}}
 async function addComment(){if(!comment.trim()||!supabase||!session){onNotice("Sign in to comment.");return}const {error}=await supabase.from("comments").insert({post_id:post.id,user_id:session.user.id,content:comment.trim()});if(error)onNotice(error.message);else{setComment("");onRefresh()}}
 return <article className="card post"><div className="posthead"><div className="avatar">{(post.author?.display_name||"K")[0].toUpperCase()}</div><div><b>{post.author?.display_name||"K.World user"}</b><div className="muted">@{post.author?.username||"user"} · {new Date(post.created_at).toLocaleString()}</div></div></div><p className="posttext">{post.content}</p>{post.media_url?(post.media_type==="video"?<video className="mediaImg" src={post.media_url} controls/>:<img className="mediaImg" src={post.media_url} alt="Post media"/>):<div className="media">K.World</div>}<div className="actions"><button onClick={like} className={liked?"action liked":"action"}><Heart size={18}/>{likes} {liked?"Liked":"Like"}</button><button className="action"><MessageSquare size={18}/>{post.comments||0} Comment</button><button className="action" onClick={()=>navigator.clipboard?.writeText(location.origin+"/?post="+post.id).then(()=>onNotice("Post link copied"))}><Share2 size={18}/>Share</button></div><div className="commentBox"><input value={comment} onChange={e=>setComment(e.target.value)} placeholder="Write a comment…" onKeyDown={e=>e.key==="Enter"&&addComment()}/><button onClick={addComment}><Send size={17}/></button></div></article>
}
