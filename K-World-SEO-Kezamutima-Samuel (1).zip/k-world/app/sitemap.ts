import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://k-world-real-fixed-3dgrxx23b-kezamutimasamuel24-4180s-projects.vercel.app";
  return [
    { url: base, lastModified: new Date(), changeFrequency: "weekly", priority: 1 },
    { url: `${base}/kezamutima-samuel`, lastModified: new Date(), changeFrequency: "monthly", priority: 0.9 },
  ];
}
