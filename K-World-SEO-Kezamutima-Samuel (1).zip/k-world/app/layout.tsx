import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://k-world-real-fixed-3dgrxx23b-kezamutimasamuel24-4180s-projects.vercel.app"),
  title: {
    default: "K.World",
    template: "%s | K.World",
  },
  description: "K.World — Connect, share and discover.",
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="rn"><body>{children}</body></html>;
}
