import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Kezamutima Samuel | Entrepreneur & Founder of K.World",
  description:
    "Kezamutima Samuel, entrepreneur and researcher from Burundi, founder of K.World and creator of digital projects including Kezatalk and Kezamutima Bet.",
  alternates: { canonical: "/kezamutima-samuel" },
  openGraph: {
    title: "Kezamutima Samuel | K.World",
    description:
      "Official profile of Kezamutima Samuel, entrepreneur, researcher and founder of K.World in Burundi.",
    type: "profile",
  },
};

const profileData = {
  "@context": "https://schema.org",
  "@type": "Person",
  name: "Kezamutima Samuel",
  jobTitle: "Entrepreneur, Researcher & Founder of K.World",
  description:
    "Entrepreneur and researcher from Burundi, founder of K.World and creator of digital projects including Kezatalk and Kezamutima Bet.",
  address: {
    "@type": "PostalAddress",
    addressCountry: "BI",
    addressLocality: "Gitega",
  },
  nationality: "Burundian",
  url: "/kezamutima-samuel",
  worksFor: {
    "@type": "Organization",
    name: "K.World",
  },
};

export default function KezamutimaSamuelPage() {
  return (
    <main className="profilePage">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(profileData) }}
      />

      <header className="profileHero">
        <a href="/" className="backLink">← K.World</a>
        <div className="profileAvatar">KS</div>
        <p className="eyebrow">PROFIL YEMEWE</p>
        <h1>Kezamutima Samuel</h1>
        <p className="role">Entrepreneur • Umushakashatsi • Founder wa K.World</p>
        <p className="heroText">
          Umuntu akora mu bijanye n&apos;ikoranabuhanga, ubushakashatsi n&apos;imishinga
          ya digitale, afise intumbero yo kubaka brand izwi kandi yubashywe mu Burundi.
        </p>
      </header>

      <section className="profileGrid">
        <article className="profileCard">
          <h2>Uwo ndi we</h2>
          <p>
            Nitwa <strong>Kezamutima Samuel</strong>. Nkomoka mu Burundi, mu ntara ya
            Gitega, commune Mutaho, ku colline Masango. Mu 2018 nimukiye mu gisagara
            ca Gitega, aho nsanzwe nkorera n&apos;ateza imbere imishinga yanje.
          </p>
          <p>
            Nkunda gukora ubushakashatsi ku mibereho y&apos;abantu no ku bidukikije.
            Ivyo niga ndabikoresha mu gutahura ibibazo, guteza imbere ivyiyumviro
            bishasha no gufata ingingo nishingiye ku bushakashatsi.
          </p>
        </article>

        <article className="profileCard">
          <h2>Ibikorwa</h2>
          <p>
            Mfise uburambe mu bikorwa bijanye na applications zo gutega, harimwo
            publicité, gufasha abakoresha kwugurura ama comptes, hamwe na dépôt na
            retrait.
          </p>
          <p className="note">
            Ibi bisobanura ibikorwa nkora; ntibisigura ko K.World ari betting platform.
          </p>
        </article>

        <article className="profileCard">
          <h2>Imishinga</h2>
          <ul>
            <li><strong>K.World</strong> — umushinga wa digitale wibanda ku guhuza abantu, gusangira no kuvumbura ibintu bishasha.</li>
            <li><strong>Kezatalk</strong> — umwe mu mishinga ya applications ya digitale.</li>
            <li><strong>Kezamutima Bet</strong> — umwe mu mishinga nteganya guteza imbere.</li>
          </ul>
        </article>

        <article className="profileCard">
          <h2>Intumbero</h2>
          <p>
            Mu gihe kiri imbere, nipfuza ko imishinga yanje ikura kandi
            <strong> K.World ikaba brand izwi kandi yubashywe mu Burundi</strong>,
            biciye mu ikoranabuhanga, ubudandaji, ubushakashatsi n&apos;imishinga ya
            digitale.
          </p>
        </article>

        <article className="profileCard full">
          <h2>Ibindi vyerekeye Kezamutima Samuel</h2>
          <div className="facts">
            <div><span>Igihugu</span><strong>Burundi</strong></div>
            <div><span>Intara</span><strong>Gitega</strong></div>
            <div><span>Commune akomokamwo</span><strong>Mutaho</strong></div>
            <div><span>Colline</span><strong>Masango</strong></div>
            <div><span>Yimukiye i Gitega</span><strong>2018</strong></div>
          </div>
        </article>
      </section>

      <footer className="profileFooter">
        <a href="/">Subira kuri K.World</a>
      </footer>
    </main>
  );
}
