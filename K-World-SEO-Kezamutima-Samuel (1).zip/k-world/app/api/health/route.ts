import { NextResponse } from "next/server"
export async function GET(){return NextResponse.json({app:"K.World",status:"ok",backendConfigured:Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL)})}
