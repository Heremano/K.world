import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return { rules: { userAgent: "*", allow: "/" }, sitemap: "https://k-world-real-fixed-3dgrxx23b-kezamutimasamuel24-4180s-projects.vercel.app/sitemap.xml" };
}
