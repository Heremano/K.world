# K.World — real Supabase social application

This package is the production K.World web app. It is not a demo: when Supabase environment variables are connected, authentication and database reads/writes use the real backend.

## Included
- Email/password signup and login
- Real Supabase profiles
- Public post creation and feed
- For You / Following / Shorts / Videos tabs
- Real likes and unlike
- Real comments
- Profile editing
- Search of loaded posts/profiles
- Mobile-first responsive interface
- RLS database schema for profiles, posts, comments, likes, follows, conversations, messages, notifications and reports

## Supabase setup
1. Create/open your Supabase project.
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. In Supabase, copy the Project URL and the **anon/public** key.
4. In Vercel, open the K.World project → Settings → Environment Variables and add:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
5. Redeploy.

Never put a Supabase `service_role` key in this Next.js client application.

## Local
Copy `.env.example` to `.env.local`, add the two public variables, then run `npm install`, `npm run dev`.
