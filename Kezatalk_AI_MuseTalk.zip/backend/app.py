import os, uuid, subprocess, shutil
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware

BASE=Path("/app/data"); BASE.mkdir(parents=True,exist_ok=True)
app=FastAPI(title="Kezatalk AI Lip Sync")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.get("/health")
def health(): return {"ok":True,"engine":"MuseTalk 1.5"}

@app.post("/generate")
async def generate(photo: UploadFile=File(...), audio: UploadFile=File(...)):
    job=BASE/uuid.uuid4().hex; job.mkdir()
    image=job/"input.png"; sound=job/"audio.wav"; out=job/"result.mp4"
    image.write_bytes(await photo.read()); sound.write_bytes(await audio.read())

    # The container expects the official MuseTalk repository and downloaded weights
    # mounted at /opt/MuseTalk. We create a short config and call its inference entrypoint.
    musetalk=os.getenv("MUSETALK_DIR","/opt/MuseTalk")
    if not Path(musetalk).exists():
        raise HTTPException(503,"MuseTalk model server is not installed. Deploy the GPU image first.")
    cfg=job/"test.yaml"
    cfg.write_text(f"""task_0:
  video_path: "{image}"
  audio_path: "{sound}"
""")
    cmd=["python","-m","scripts.inference",
         "--inference_config",str(cfg),
         "--result_dir",str(job/"results"),
         "--unet_model_path",f"{musetalk}/models/musetalkV15/unet.pth",
         "--unet_config",f"{musetalk}/models/musetalkV15/musetalk.json",
         "--version","v15",
         "--ffmpeg_path",os.getenv("FFMPEG_PATH","ffmpeg")]
    p=subprocess.run(cmd,cwd=musetalk,text=True,capture_output=True,timeout=3600)
    candidates=list((job/"results").rglob("*.mp4"))
    if p.returncode!=0 or not candidates:
        raise HTTPException(500, p.stderr[-3000:] or "AI generation failed")
    shutil.copy2(candidates[0],out)
    return FileResponse(out,media_type="video/mp4",filename="kezatalk-ai.mp4")
