# Kezatalk Studio AI — MuseTalk 1.5

This is a deploy-ready architecture for REAL AI lip-sync:
Photo + user's audio -> MuseTalk 1.5 -> MP4.

MuseTalk is an open-source audio-driven lip-sync model. It supports image/video input and multiple languages. It requires a GPU for practical speed.

## Important
1. This package does not include model weights.
2. Deploy backend on a CUDA/NVIDIA GPU server (RunPod, a GPU VM, etc.).
3. Download MuseTalk 1.5 weights and its required component weights into `/opt/MuseTalk/models` as described by the official project.
4. Start backend with Docker.
5. Put the backend URL into the frontend's `KEZATALK_API` localStorage setting or replace the default API URL.
6. Deploy frontend to Vercel.

## 12,000 seconds
For very long audio, production should split the audio into chunks, process them sequentially, then concatenate with FFmpeg. Do not send a 3h20m file as one GPU job.

## License / commercial use
MuseTalk's repository states its code and trained model are available under its stated terms, but its other open-source components have their own licenses. Review those licenses before commercial deployment.
